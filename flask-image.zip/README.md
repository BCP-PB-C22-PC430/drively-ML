# Bangkit Flask

A Flask for serving API to Google Cloud VM to predict video frames of human faces and returns the drowsiness status.
